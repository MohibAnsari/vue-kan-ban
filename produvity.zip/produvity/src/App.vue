<script setup></script>

<template>
  <div id="main" class="p-8 h-screen w-screen">
    <router-view />
  </div>
</template>

<style scoped>
#main {
  background-image: url(/aurora.jpg);
  height: 100vh;
  width: 100vw;
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  display: flex;
  font-family: "Inter", sans-serif;
}
</style>
