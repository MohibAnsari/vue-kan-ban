import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyB0GlcEjZ6sQzkWT2f2R5UAxNVjNTb4eqY",
  authDomain: "produvity-26eaa.firebaseapp.com",
  projectId: "produvity-26eaa",
  storageBucket: "produvity-26eaa.appspot.com",
  messagingSenderId: "358022147043",
  appId: "1:358022147043:web:b5d2fa861b9fb7fd3bced6"
};
  
const app = initializeApp(firebaseConfig);
const db = getFirestore(app)

export { db }