import Home from './views/Home.vue'
import Kanban from './views/Kanban.vue'
import NotFound from './views/NotFound.vue'
import Login from './views/Login.vue'
import { createRouter, createWebHistory } from 'vue-router'

/** @type {import('vue-router').RouterOptions['routes']} */
const routes = [
  { path: '/', component: Login, meta: { title: 'Login' } },
  { path: '/boards', component: Home, meta: { title: 'Home' } },
  {
    path: "/boards/:id",
    meta: {title: "Kanban"},
    component: Kanban
  },
  { path: '/:path(.*)', component: NotFound },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export { router } 