<script setup>
import { ref } from "vue";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from "firebase/auth";
import { useMainStore } from "@/store/main";
import { router } from "@/routes";
const store = useMainStore();

const showLogin = ref(true);
const title = ref("Login");
const resetTitle = () => {
  title.value = showLogin.value ? "Login" : "Registrieren";
};
const toggleLogin = () => {
  showLogin.value = !showLogin.value;
  resetTitle();
};

const noSpinner = ref(true);

const email = ref("");
const password = ref("");

const submitLogin = () => {
  noSpinner.value = false;
  const auth = getAuth();
  signInWithEmailAndPassword(auth, email.value, password.value)
    .then((_userCredential) => {
      store.userid = auth.currentUser.uid;
      localStorage.setItem("userid", auth.currentUser.uid);
      router.push({ path: "/boards" });
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      console.log(errorCode);
      console.log(errorMessage);
    });
};

const submitRegister = () => {
  const auth = getAuth();
  createUserWithEmailAndPassword(auth, email.value, password.value)
    .then((_userCredential) => {
      store.userid = auth.currentUser.uid;
      localStorage.setItem("userid", auth.currentUser.uid);
      router.replace({ path: "/boards" });
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      console.log(errorCode);
      console.log(errorMessage);
      // ..
    });
};
</script>

<template>
  <div class="w-full flex justify-center items-center">
    <base-card class="p-16 flex flex-col justify-center items-center">
      <h1>{{ title }}</h1>
      <form class="mt-8">
        <div class="form-group flex flex-col">
          <label for="username">E-Mail</label>
          <input
            type="email"
            v-model="email"
            class="rounded-full mt-2 outline-none border-2 focus:invalid:border-pink-500"
          />
        </div>
        <div class="form-group flex flex-col mt-4">
          <label for="password">Passwort</label>
          <input
            type="password"
            name="password"
            v-model="password"
            class="rounded-full mt-2 outline-none border-2 focus:invalid:border-pink-500"
          />
        </div>
        <div class="flex flex-col justify-center items-center">
          <button
            v-if="showLogin"
            @click.prevent="submitLogin"
            class="bg-fuchsia-700 text-white font-bold w-full py-3 rounded-xl mt-8"
          >
            <span v-if="noSpinner">Login</span><span v-else>Einen Moment bitte...</span>
          </button>
          <button
            @click.prevent="submitRegister"
            v-else
            class="bg-fuchsia-700 text-white font-bold w-full py-3 rounded-xl mt-8"
          >
            Register
          </button>
          <a v-if="showLogin" @click="toggleLogin" href="#" class="mt-4 text-xs"
            >Noch kein Account? Hier registrieren
          </a>
          <a v-else @click="toggleLogin" href="#" class="mt-4 text-xs"
            >Bereits registriert? Zum Login</a
          >
        </div>
      </form>
    </base-card>
  </div>
</template>
