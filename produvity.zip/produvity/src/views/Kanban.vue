<script setup>
import BoardHeader from "@/components/BoardHeader.vue";
import KanbanSlot from "@/components/KanbanSlot.vue";
import { useRoute } from "vue-router";
import { useMainStore } from "@/store/main";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/firebase";
import { ref, onBeforeMount } from "vue";

const store = useMainStore();

const route = useRoute();
const ROUTE_ID = route.params.id;

const Backlog = "Backlog";
const inArbeit = "in Arbeit";
const PeerReview = "Peer Review";
const erledigt = "erledigt";

const backlogData = ref([]);
const inArbeitData = ref([]);
const peerReviewData = ref([]);
const erledigtData = ref([]);

onBeforeMount(async () => {
  const snapshot = await getDoc(
    doc(db, store.userid || localStorage.getItem("userid"), ROUTE_ID)
  );
  const snapshotData = snapshot.data();
  backlogData.value = Object.values(snapshotData.Backlog);
  inArbeitData.value = Object.values(snapshotData.inArbeit);
  peerReviewData.value = Object.values(snapshotData.PeerReview);
  erledigtData.value = Object.values(snapshotData.erledigt);
});

const slotChanged = (event) => {
  console.log(event);
};
</script>
<template>
  <div class="w-full">
    <board-header @cardAdded="cardAdded"></board-header>
    <div class="w-full h-5/6 mt-8 flex justify-between">
      <kanban-slot
        :slotTitle="Backlog"
        :data="backlogData"
        class="mx-8 w-full"
        @change="slotChanged"
      ></kanban-slot>
      <kanban-slot
        :slotTitle="inArbeit"
        :data="inArbeitData"
        class="mr-8 w-full"
      ></kanban-slot>
      <kanban-slot
        :slotTitle="PeerReview"
        :data="peerReviewData"
        class="mr-8 w-full"
      ></kanban-slot>
      <kanban-slot
        :slotTitle="erledigt"
        :data="erledigtData"
        class="w-full"
      ></kanban-slot>
    </div>
  </div>
</template>
