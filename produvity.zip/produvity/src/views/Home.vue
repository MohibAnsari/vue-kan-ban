<script setup>
import BaseCard from "@/components/BaseCard.vue";
import ProjectHub from "@/components/ProjectHub.vue";
import CreateNewBoard from "@/components/CreateNewBoard.vue";
import { collection, query, getDocs } from "firebase/firestore";
import { getAuth, signOut } from "firebase/auth";
import { db } from "@/firebase";
import { ref } from "vue";
import { useMainStore } from "@/store/main";
import { router } from "@/routes";

const store = useMainStore();
const modalOpen = ref(false);
let dataLoaded = false;

// const condition = where("id", "!=", "Stats");
// const q = query(collection(db, "Daniel"), condition);
const q = query(collection(db, store.userid || localStorage.getItem("userid")));
getDocs(q)
  .then((snapshot) => {
    const arrayBoards = [];
    const boards = snapshot.docs;
    store.numOfBoards = boards.length;
    boards.forEach((doc) => arrayBoards.push({ id: doc.id, data: doc.data() }));
    store.boards = arrayBoards;
  })
  .then((dataLoaded = true));

const logout = () => {
  const auth = getAuth();
  signOut(auth)
    .then(() => {
      router.replace({ path: "/" });
    })
    .catch((error) => {
      console.log(error);
    });
};
</script>

<template>
  <div class="w-full ml-8 flex flex-col items-center">
    <base-card
      class="w-full text-2xl font-bold flex justify-between items-center px-4 py-12"
    >
      <h1 class="bg-fuchsia-700 rounded-xl px-3 py-3 text-lg text-white">
        {{ store.numOfBoards }} / 4
      </h1>
      <h1>Boards Übersicht</h1>
      <button
        @click="logout"
        class="px-8 text-lg text-white bg-fuchsia-700 hover:bg-fuchsia-800 rounded-full py-3"
      >
        Logout
      </button>
    </base-card>
    <button
      v-if="store.numOfBoards <= 3"
      @click="modalOpen = !modalOpen"
      class="addBtn w-fit px-12 py-3 mt-8 ml-8 font-bold text-fuchsia-700 bg-fuchsia-200 hover:bg-fuchsia-300 rounded-full border-dashed border-2 border-fuchsia-700"
    >
      + Neues Board anlegen
    </button>
    <project-hub class="mt-8" v-if="dataLoaded"></project-hub>
  </div>
  <Teleport to="body">
    <create-new-board
      v-if="modalOpen"
      @backdropClicked="modalOpen = !modalOpen"
    ></create-new-board>
  </Teleport>
</template>
