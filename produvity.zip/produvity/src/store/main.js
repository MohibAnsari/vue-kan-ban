import { defineStore } from "pinia"

export const useMainStore = defineStore("main", {
    state: () => ({
        numOfBoards: 0,
        boards: [],
        userid: "",
        reloadKanban: 0
    }),
    getters: {
        getnumOfBoards: state => {
            return state.numOfBoards
        }
    }
})