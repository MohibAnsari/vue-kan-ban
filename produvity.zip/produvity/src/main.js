import { createApp } from 'vue'
import './tailwind.css'
import App from './App.vue'
import { router } from './routes.js'
import { createPinia } from "pinia"

import BaseCard from "@/components/BaseCard.vue"

const app = createApp(App)

app.use(router)
app.component("BaseCard", BaseCard)
app.use(createPinia())
app.mount('#app')
