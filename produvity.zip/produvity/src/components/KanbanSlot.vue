<script setup lang="ts">
import KanbanCard from "@/components/KanbanCard.vue";
import { VueDraggableNext as draggable } from "vue-draggable-next";
import { ref, computed } from "vue";

const props = defineProps({
  slotTitle: String,
  data: [Object, Array],
  propsArray: [],
});

const data = computed(() => {
  return props.data;
});

const drag = ref(false);
const start = () => {
  drag.value = true;
};
const end = () => {
  drag.value = false;
};

const checkMove = (event) => {};
const log = (event) => {
  const { moved, added } = event;
  if (moved) console.log("moved", moved);
  if (added) console.log("added", added, added.element, data.value);
};
</script>
<template>
  <div class="relative">
    <base-card class="text-lg font-extrabold flex justify-center items-center z-10">{{
      props.slotTitle
    }}</base-card>
    <draggable
      :list="data"
      :group="{ name: 'board' }"
      :sort="true"
      @start="start"
      @end="end"
      @change="log"
      :move="checkMove"
      class="mt-8 px-4 dropZone w-full"
    >
      <kanban-card
        v-for="(_card, idx) in data"
        :key="idx"
        :content="data[idx]"
        class="mt-4 z-50"
      ></kanban-card>
    </draggable>
  </div>
</template>

<style scoped>
.dropZone {
  height: calc(100% - 5.5rem);
  background: linear-gradient(
    173.15deg,
    rgba(214, 219, 223, 0.175) 5.12%,
    rgba(186, 182, 199, 0.175) 95.76%
  );
  border: 1px solid #ffffff;
  box-sizing: border-box;
  backdrop-filter: blur(31px);
  border-radius: 20px;
  overflow: hidden;
}
</style>
