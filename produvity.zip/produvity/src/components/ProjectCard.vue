<script setup lang="ts">
import { computed } from "vue";
import { db } from "@/firebase";
import { doc, deleteDoc } from "firebase/firestore";
import { useMainStore } from "@/store/main.js";

const emit = defineEmits(["reloadTrigger"]);
const store = useMainStore();

const props = defineProps({
  singleboard: Object,
});

const id = props.singleboard.id;

async function deleteBoard() {
  console.log("Moinsen");
  const docRef = doc(db, store.userid || localStorage.getItem("userid"), id);
  await deleteDoc(docRef);
  store.boards = store.boards.filter((board) => board.id !== id);
  emit("reloadTrigger");
  store.numOfBoards -= 1;
}

const data = computed(() => {
  return props.singleboard.data;
});

const symbol = computed(() => {
  if (id) {
    return props.singleboard.id.split("")[0];
  }
});
</script>
<template>
  <base-card
    @click="$router.push({ path: `/boards/${id}` })"
    class="p-6 flex justify-between hover:bg-fuchsia-50 hover:cursor-pointer"
  >
    <div class="flex">
      <div
        class="h-14 w-14 bg-fuchsia-700 rounded-xl text-white font-bold text-2xl flex justify-center items-center"
      >
        {{ symbol }}
      </div>
      <div class="ml-8">
        <h1 class="font-black text-2xl" v-if="id">
          {{ id }}
        </h1>
        <p class="font-thin">in Arbeit</p>
        <div class="mt-8">
          <p>
            {{ !data.hasOwnProperty("Backlog") ? "Keine" : data.Backlog.length }} Cards im
            <span class="text-fuchsia-700 font-black">Backlog</span>
          </p>
          <p>
            {{ !data.hasOwnProperty("inArbeit") ? "Keine" : data.inArbeit.length }} Cards
            <span class="text-fuchsia-700 font-black">in Arbeit</span>
          </p>
          <p>
            {{ !data.hasOwnProperty("PeerReview") ? "Keine" : data.PeerReview.length }}
            Cards im <span class="text-fuchsia-700 font-black">Peer Review</span>
          </p>
          <p>
            {{ !data.hasOwnProperty("erledigt") ? "Keine" : data.erledigt.length }} Cards
            <span class="text-fuchsia-700 font-black">in erledigt</span>
          </p>
        </div>
      </div>
    </div>
    <svg
      @click.stop="deleteBoard"
      xmlns="http://www.w3.org/2000/svg"
      class="h-8 w-8 text-fuchsia-700"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        stroke-linecap="round"
        stroke-linejoin="round"
        stroke-width="2"
        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
      />
    </svg>
  </base-card>
</template>

<style scoped>
.marker {
  background-color: rgba(182, 97, 184, 0.75);
}
</style>
