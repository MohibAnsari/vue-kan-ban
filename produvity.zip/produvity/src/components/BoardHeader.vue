<script setup>
import { useRoute } from "vue-router";
import { ref } from "vue";
import { db } from "@/firebase";
import { doc, updateDoc, arrayUnion } from "firebase/firestore";
import { useMainStore } from "@/store/main";

const store = useMainStore();

const route = useRoute();
const ROUTE_ID = route.params.id;
const symbol = ROUTE_ID.split("")[0];

const showModal = ref(false);
const toggleModal = () => {
  showModal.value = !showModal.value;
};

const marker = ref("");
const cardName = ref("");

const emit = defineEmits("cardAdded");

const addCard = async () => {
  await updateDoc(doc(db, localStorage.getItem("userid"), ROUTE_ID), {
    Backlog: arrayUnion({ MARKER: marker.value, Text: cardName.value }),
  });
  showModal.value = !showModal;
  location.reload(true);
};
</script>

<template>
  <BaseCard class="ml-8 px-8 py-8 flex justify-between">
    <div class="flex">
      <img
        @click="$router.push({ path: '/boards' })"
        src="../../public/left-arrow.png"
        alt="zurück"
      />
      <div
        class="ml-8 h-14 w-14 bg-fuchsia-700 rounded-xl text-white font-bold text-2xl flex justify-center items-center"
      >
        {{ symbol }}
      </div>
      <div class="ml-8">
        <h1 class="text-2xl font-extrabold">{{ ROUTE_ID }}</h1>
        <p>in Arbeit</p>
      </div>
    </div>
    <button
      @click="toggleModal"
      class="bg-fuchsia-700 rounded-xl text-white font-bold px-8"
    >
      + Neue Aufgabe
    </button>
  </BaseCard>
  <Teleport to="body">
    <div
      v-if="showModal"
      @click.self="toggleModal"
      class="absolute top-0 flex justify-center items-center w-screen h-screen bg-slate-500/50"
    >
      <base-card class="p-12">
        <h1 class="font-bold mb-4">Neue Aufgabe erstellen</h1>
        <div class="form-group flex flex-col">
          <label for="marker">Marker</label>

          <select v-model="marker" name="marker">
            <option value="DESIGN" selected>DESIGN</option>
            <option value="CODING">CODING</option>
            <option value="RESEARCH">RESEARCH</option>
            <option value="WRITING">WRITING</option>
          </select>
        </div>
        <div class="form-group flex flex-col mt-4">
          <label for="cardName">Text</label>
          <input v-model="cardName" type="text" placeholder="Text" />
        </div>
        <button
          @click="addCard"
          class="bg-fuchsia-700 text-white font-bold w-full py-3 rounded-xl mt-8"
        >
          Hinzufügen
        </button>
      </base-card>
    </div>
  </Teleport>
</template>
