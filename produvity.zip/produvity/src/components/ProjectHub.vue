<script setup>
import ProjectCard from "@/components/ProjectCard.vue";
import { useMainStore } from "@/store/main.js";
import { ref } from "vue";

const store = useMainStore();

const reload = ref(0);
const setBoards = () => {
  reload.value++;
};
</script>
<template>
  <div class="grid gap-8 grid-cols-2 w-full" :key="reload">
    <project-card
      v-if="store.boards.length"
      v-for="(_board, idx) in store.boards"
      :singleboard="store.boards[idx]"
      @reloadTrigger="setBoards"
    >
    </project-card>
  </div>
</template>
