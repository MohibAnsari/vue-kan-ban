<script setup>
const props = defineProps({
  content: Object,
});
</script>
<template>
  <base-card>
    <p class="bg-fuchsia-300 w-fit px-4 py-1 rounded-xl text-white text-xs font-extrabold">
      {{ props.content.MARKER }}
    </p>
    <p class="mt-4 text-xs">
      {{ props.content.Text }}
    </p>
  </base-card>
</template>
