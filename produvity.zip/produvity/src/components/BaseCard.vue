<template>
    <div class="basecard p-4 bg-white">
        <slot></slot>
    </div>
</template>

<style scoped>
.basecard {
    box-shadow: 4px 4px 30px rgba(0, 0, 0, 0.1), inset 12px 12px 38px rgba(234, 248, 252, 0.1), inset -12px -12px 36px rgba(116, 147, 165, 0.05);
border-radius: 20px;
}
</style>