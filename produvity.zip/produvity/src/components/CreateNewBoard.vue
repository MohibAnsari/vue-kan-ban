<script setup="props, { emit }">
import { ref } from "vue";
import { useMainStore } from "@/store/main.js";
import { db } from "../firebase";
import { doc, setDoc } from "firebase/firestore";
import { router } from "@/routes";

const store = useMainStore();

const emit = defineEmits(["backdropClicked"]);

const newBoardName = ref("");

const emitClick = () => {
  emit("backdropClicked");
};

let submitError = ref(false);
let errorText = ref("");
async function submitBoard() {
  if (newBoardName.value.length < 3) {
    submitError = true;
    errorText.value = "Der Boardname muss mindestens 3 Buchstaben lang sein.";
    return;
  }
  store.boards.forEach((board) => {
    if (board.id === newBoardName.value) {
      submitError = true;
      errorText.value =
        "Dieses Board existiert bereits. Bitte wähle einen anderen Namen.";
      return;
    }
  });
  await setDoc(
    doc(db, store.userid || localStorage.getItem("userid"), newBoardName.value),
    {
      Backlog: [],
      inArbeit: [],
      PeerReview: [],
      erledigt: [],
    }
  );
  router.push({ path: `/boards/${newBoardName.value}`, replace: true });
}
</script>

<template>
  <div
    @click.self="emitClick"
    class="absolute h-full w-full top-0 bg-black/70 flex justify-center items-center"
  >
    <base-card class="px-12 py-20 w-3/6">
      <h1 class="text-2xl font-bold">Neues Board anlegen</h1>
      <div class="flex flex-col py-8">
        <label for="boardName">Titel</label>
        <input
          v-model="newBoardName"
          type="text"
          name="boardName"
          placeholder="Mein neues Projekt"
          class="rounded-full mt-2 outline-none border-2 focus:invalid:border-pink-500"
        />
        <p>{{ errorText }}</p>
      </div>
      <button
        class="font-bold text-white bg-fuchsia-700 hover:bg-fuchsia-800 rounded-full py-3 w-full"
        @click="submitBoard"
      >
        Erstellen
      </button>
    </base-card>
  </div>
</template>
